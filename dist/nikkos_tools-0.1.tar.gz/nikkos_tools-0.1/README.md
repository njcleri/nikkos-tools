# nikkos-tools

[![PyPI - Version](https://img.shields.io/pypi/v/nikkos-tools.svg)](https://pypi.org/project/nikkos-tools)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/nikkos-tools.svg)](https://pypi.org/project/nikkos-tools)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install nikkos-tools
```

## License

`nikkos-tools` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
