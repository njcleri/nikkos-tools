# SPDX-FileCopyrightText: 2024-present njcleri <nikko.cleri@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"
